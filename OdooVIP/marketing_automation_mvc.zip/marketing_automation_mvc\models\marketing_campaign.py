from odoo import models, fields

class MarketingCampaign(models.Model):
    _name = 'mvc.marketing.campaign'
    _description = 'Marketing Automation Campaign'

    name = fields.Char(string='Campaign Name', required=True)
    active = fields.Boolean(default=True)
    start_date = fields.Datetime(string='Start Date')
    end_date = fields.Datetime(string='End Date')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('running', 'Running'),
        ('stopped', 'Stopped'),
        ('completed', 'Completed')
    ], string='Status', default='draft')
    description = fields.Text(string='Description')
